package com.example.app.service;


import org.springframework.stereotype.Service;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
public class ThreadService {
    private final ExecutorService executorService = Executors.newFixedThreadPool(10);

    public void processTasks(List<Runnable> tasks) {
        tasks.forEach(executorService::submit);
    }

    public void shutdownExecutor() {
        executorService.shutdown();
    }
}