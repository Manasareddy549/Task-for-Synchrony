package com.example.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.app.entity.User;
import com.example.app.service.UserService;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

@Component
public class PerformanceTestRunner implements CommandLineRunner {

    @Autowired
    private UserService userService;

    @Override
    public void run(String... args) throws Exception {
        int testSize = 100; // Number of test operations
        List<User> testUsers = createTestUsers(testSize);

        // Sequential Execution
        System.out.println("Running Sequential Execution...");
        long sequentialTime = executeSequentially(testUsers);
        System.out.println("Sequential Execution Time: " + sequentialTime + "ms");

        // Parallel Execution
        System.out.println("Running Parallel Execution...");
        long parallelTime = executeInParallel(testUsers);
        System.out.println("Parallel Execution Time: " + parallelTime + "ms");

        // Report Results
        System.out.println("Performance Improvement: " + ((sequentialTime - parallelTime) * 100.0 / sequentialTime) + "%");
    }

    private List<User> createTestUsers(int size) {
        List<User> users = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            User user = new User();
            user.setName("User" + i);
            user.setEmail("user" + i + "@example.com");
            users.add(user);
        }
        return users;
    }

    private long executeSequentially(List<User> users) {
        long startTime = System.currentTimeMillis();
        for (User user : users) {
            userService.saveUser(user);
            userService.getUserById(user.getId());
            userService.deleteUserById(user.getId());
        }
        return System.currentTimeMillis() - startTime;
    }

    private long executeInParallel(List<User> users) throws InterruptedException, ExecutionException {
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        List<Callable<Void>> tasks = new ArrayList<>();

        for (User user : users) {
            tasks.add(() -> {
                userService.saveUser(user);
                userService.getUserById(user.getId());
                userService.deleteUserById(user.getId());
                return null;
            });
        }

        long startTime = System.currentTimeMillis();
        executorService.invokeAll(tasks);
        executorService.shutdown();
        executorService.awaitTermination(10, TimeUnit.SECONDS);
        return System.currentTimeMillis() - startTime;
    }
}
