package com.example.app;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;

import com.example.app.entity.User;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AppApplicationTests {
    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void testCreateAndGetUser() {
        User user = new User();
        user.setName("Jane");
        user.setEmail("jane@example.com");

        ResponseEntity<User> createResponse = restTemplate.postForEntity("/users", user, User.class);
        assertNotNull(createResponse.getBody().getId());

        Long userId = createResponse.getBody().getId();
        ResponseEntity<User> getResponse = restTemplate.getForEntity("/users/" + userId, User.class);

        assertEquals("Jane", getResponse.getBody().getName());
    }
}
